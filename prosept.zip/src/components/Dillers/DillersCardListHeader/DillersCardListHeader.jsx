// import React, { Component } from 'react';
// import {BootstrapTable, 
//        TableHeaderColumn} from 'react-bootstrap-table';
// import { useTable } from 'react-table';
import "./DillersCardListHeader.css";

export function DillersCardListHeader() {
    // const tableInstance = useTable(options)
    return (
        // <div className="dillers_card_list_header">
        //     <p>Product</p>
        //     <p>SKU</p>
        //     <p>МинРРЦ</p>
        //     <p>РРЦ</p>
        //     <p>Moi_vibor_WB</p>
        //     <p>Akson</p>
        //     <p>Bafus</p>
        //     <p>Castorama</p>
        //     <p>Cubatora</p>
        //     <p>Komus</p>
        //     <p>Megastroy</p>
        //     <p>OnlineTrade</p>
        // </div>
        <></>
    )
}