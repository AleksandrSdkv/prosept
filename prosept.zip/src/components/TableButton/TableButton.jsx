export function TableButton({ nameBtn }) {
  return <button className="button-table">{nameBtn}</button>;
}
